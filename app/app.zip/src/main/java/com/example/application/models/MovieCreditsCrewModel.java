package com.example.application.models;

import java.util.List;

public class MovieCreditsCrewModel extends PersonModel {
    private String department;
    private String job;

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }
}
