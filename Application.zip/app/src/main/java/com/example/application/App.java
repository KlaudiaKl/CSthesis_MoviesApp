package com.example.application;

import androidx.multidex.MultiDexApplication;

import dagger.hilt.android.HiltAndroidApp;

@HiltAndroidApp
public final class App extends MultiDexApplication {

}
