package com.example.application.models;

public class CategoryModel {

    private String categoryName;

    public CategoryModel(String categoryName){
        this.categoryName = categoryName;
    }

    public String getCategoryName() {
        return categoryName;
    }
}
