package com.example.application;

import com.example.application.models.MovieDetailsModel;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface DetailsInterface {

}
